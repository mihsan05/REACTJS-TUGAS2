export default function Hero() {
    return(
        <>
                {/* heroes */ }  {/* Home Content */}
        <div id="Home" className="container my-5">
  <div className="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
    <div className="col-lg-7 p-3 p-lg-5 pt-lg-3">
    <h1 className="display-4 fw-bold lh-1 text-body-emphasis">
    <i className="bi bi-mortarboard-fill"></i> XannPedia:
</h1>

      <p className="lead">
      Hai, Selamat datang di Xannpedia! Yuk, jelajahi ribuan buku, pengetahuan, dan cerita seru yang siap menemani harimu
      </p>
      <div className="d-grid gap-2 d-md-flex justify-content-md-start mb-4 mb-lg-3">
        <button type="button" className="btn btn-primary btn-lg px-4 me-md-2 fw-bold">Pesan sekarang</button>

      </div>
    </div>
    <div className="col-lg-4 offset-lg-1">
  <div className="border border-primary rounded-4 shadow-lg bg-white" style={{ padding: '10px' }}>
    <img
      className="rounded-3"
      src="https://picsum.photos/600/400?random=4"
      alt="Bootstrap Docs"
      style={{ display: 'block', width: '100%', height: 'auto' }}
    />
  </div>
</div>

  </div>
</div>



              {/* Bagian Card Kategori Buku */}
              <div className="container px-4 py-5" id="custom-cards">
  <h2 className="pb-2 border-bottom">Book Categories</h2>

  <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4 py-4">
    {/* Card 1 */}
    <div className="col">
      <div className="card h-100 text-white bg-dark shadow-sm">
        <img src="https://picsum.photos/600/400?random=1" className="card-img-top" alt="Fiksi" />
        <div className="card-body">
          <h5 className="card-title">Fiksi</h5>
          <p className="card-text">Buku yang berisi cerita imajinatif seperti novel, cerpen, fantasi, hingga drama romantis.</p>
        </div>
      </div>
    </div>

    {/* Card 2 */}
    <div className="col">
      <div className="card h-100 text-white bg-dark shadow-sm">
        <img src="https://picsum.photos/600/400?random=2" className="card-img-top" alt="Non Fiksi" />
        <div className="card-body">
          <h5 className="card-title">Non Fiksi</h5>
          <p className="card-text">Kategori buku berdasarkan fakta dan realita seperti biografi, sejarah, dan sains populer.</p>
        </div>
      </div>
    </div>

    {/* Card 3 */}
    <div className="col">
      <div className="card h-100 text-white bg-dark shadow-sm">
        <img src="https://picsum.photos/600/400?random=3" className="card-img-top" alt="Teknologi" />
        <div className="card-body">
          <h5 className="card-title">Teknologi</h5>
          <p className="card-text">Buku tentang perkembangan teknologi, komputer, pemrograman, dan dunia digital modern.</p>
        </div>
      </div>
    </div>

    {/* Card 4 */}
    <div className="col">
      <div className="card h-100 text-white bg-dark shadow-sm">
        <img src="https://picsum.photos/600/400?random=4" className="card-img-top" alt="Bisnis & Ekonomi" />
        <div className="card-body">
          <h5 className="card-title">Bisnis & Ekonomi</h5>
          <p className="card-text">Berisi pengetahuan tentang manajemen, keuangan, investasi, dan strategi bisnis modern.</p>
        </div>
      </div>
    </div>
  </div>
</div>
        </>
    )
}