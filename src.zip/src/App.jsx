import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from "./components/shared/Header";
import Footer from "./components/shared/Footer";
import Hero from "./components/shared/Hero";
import Productlist from "./components/shared/Productlist";
import Team from "./components/shared/Team";
import Contact from "./components/shared/Contact";

const Home = () => <div>Home Page</div>;  // Definisikan komponen Home
const Book = () => <div>Book Page</div>;  // Definisikan komponen Book

function App() {
  return (
    <Router>
      <div className="container">
        <Header />

        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <Productlist />
              <Team />
              <Contact />
            </>
          } />

          <Route path="/home" element={<Home />} />
          <Route path="/book" element={<Book />} />
          <Route path="/product" element={<Productlist />} />
          <Route path="/team" element={<Team />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
